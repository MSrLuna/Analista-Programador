suma = 0
for i in range(5):
    numero = float(input("Ingrese un número: "))
    suma += numero
    print("La sumatoria acumulada es:", suma)