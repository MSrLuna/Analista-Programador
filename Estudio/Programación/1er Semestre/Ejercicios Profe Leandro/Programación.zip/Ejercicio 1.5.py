while True:
    num = int(input("Ingresa un número entero: "))
    if num > 0:
        print("Positivo")
        print(num)
    else:
        break