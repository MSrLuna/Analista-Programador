nombre_cliente = input("Ingrese el nombre y el apellidodel cliente: ")
fecha = input("Ingrese la fecha (DD/MM/AAAA): ")
cantidad = int(input("Ingrese la cantidad de productos: "))
producto = input("Ingrese el nombre del producto: ")
precio = float(input("Ingrese el precio del producto: "))
neto = cantidad * precio
iva = neto * 0.19
total = neto + iva
print("Nombre del cliente:", nombre_cliente)
print("Fecha:", fecha)
print("Cantidad:", cantidad)
print("Producto:", producto)
print("Precio unitario:", precio)
print("Neto:", neto)
print("IVA (19%):", iva)
print("Total:", total)