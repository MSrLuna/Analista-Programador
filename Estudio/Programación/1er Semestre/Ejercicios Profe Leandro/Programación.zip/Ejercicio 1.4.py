suma_ventas = 0
for mes in range(1, 13):
    venta = float(input("Ingrese la venta del mes {}: ".format(mes)))
    suma_ventas += venta
promedio_anual = suma_ventas / 12
print("El promedio anual de ventas es:", promedio_anual)