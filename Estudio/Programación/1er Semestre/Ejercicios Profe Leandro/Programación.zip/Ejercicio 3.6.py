contador = 1
while contador <= 10:
    numero = int(input("Ingrese un número: "))
    print(numero)
    contador += 1

print(contador)("Los 10 números ya se han ingresado satisfactoriamente")