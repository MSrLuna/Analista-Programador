num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
num3 = float(input("Ingresa el tercer número: "))
num4 = float(input("Ingresa el cuarto número: "))
num5 = float(input("Ingresa el quinto número: "))
suma = num1 + num2 + num3 + num4 + num5
print("La suma de los 5 números ingresados es:", suma)