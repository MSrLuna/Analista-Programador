total_venta = 0
for i in range(10):
    codigo = input("Ingrese el código del ticket: ")
    precio = float(input("Ingrese el precio del ticket: "))
    total_venta += precio

if total_venta > 20000:
    descuento = total_venta * 0.085
    total_venta -= descuento

print("El total de la venta es:", total_venta)