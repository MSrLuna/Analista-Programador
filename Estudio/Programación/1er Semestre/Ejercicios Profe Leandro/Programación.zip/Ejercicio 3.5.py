for i in range(120, 0, -8):
    print(i)
